package gr.aueb.cf.ch15;

 public class PointUtil {

    private PointUtil() {}

    public static double getDistanceFromOrigin(Point point) {

        return point.getDistanceFromOrigin();
    }

}

package gr.aueb.cf.ch15;

public class Point {

    private double x;

    public Point() {
        x = 8;
    }

    public Point(double x) {
        this.x = 0;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public String convertToString() {
        return "(" + x + ")";
    }

    /**
     * @implSpec
     *
     */

    public void movePlus10() {
        x += 10;
    }

//        for (int i = 1; i <= 10; i++) {
//            movePlusOne();
//        }

    protected void movePlusOne() {
        x += 1;
    }

    protected void printTypeof() {
        System.out.println(this.getClass().getSimpleName());
    }

    private void reset() {
        x = 0;
    }

    public double getDistanceFromOrigin() {
        double distance;
        distance = x ;

        return distance;
    }

}

package gr.aueb.cf.ch16;

public interface ICircle extends ITwoDimensional, IShape{

    double getDiameter();
}

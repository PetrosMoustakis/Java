package gr.aueb.cf.ch16;

@FunctionalInterface
public interface IShape {

    /**
     * Returns the id of a key
     * @return the ID
     */

    long getId();
}

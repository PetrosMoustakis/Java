package gr.aueb.cf.ch16;

@FunctionalInterface
public interface ILine extends IShape {

}

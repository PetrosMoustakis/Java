package gr.aueb.cf.ch16;

public interface IRectangle extends ITwoDimensional, IShape {

}

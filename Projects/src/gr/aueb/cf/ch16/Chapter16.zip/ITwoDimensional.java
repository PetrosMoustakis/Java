package gr.aueb.cf.ch16;

public interface ITwoDimensional {

    double getArea();
    double getCircumference();
}

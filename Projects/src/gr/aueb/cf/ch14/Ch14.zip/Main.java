package gr.aueb.cf.ch14;

public class Main {
    public static void main(String[] args) {
        SaintGeorgeKnight saintGeorgeKnight = SaintGeorgeKnight.getInstance();
        saintGeorgeKnight.embarkOnMission();
    }
}

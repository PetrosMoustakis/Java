package gr.aueb.cf.ch18.model;

public interface IdentifiableEntity {

    public Long getId();
}

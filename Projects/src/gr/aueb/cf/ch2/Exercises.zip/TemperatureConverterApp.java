package gr.aueb.cf.ch2;

import java.util.Scanner;

public class TemperatureConverterApp {

    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);
        int f = 0;
        int c = 0;

        System.out.println("Please insert temperature in Fahrenheit");
        f = in.nextInt();

        c = (5 * (f - 32))/ 9;

        System.out.println("The temperature in Celsius is:" + c);

    }
}
